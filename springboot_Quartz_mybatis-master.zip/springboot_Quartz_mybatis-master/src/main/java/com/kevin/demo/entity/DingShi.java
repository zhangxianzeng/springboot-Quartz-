package com.kevin.demo.entity;

import lombok.Data;

@Data
public class DingShi {
    private String name;
    private String password;
}
