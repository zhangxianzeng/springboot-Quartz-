package com.kevin.demo.entity;

import com.kevin.demo.controller.QuartzController;
import com.kevin.demo.mapper.TaskMapper;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.quartz.QuartzJobBean;

import java.util.Date;

/**
 * @Description:    任务器
 * @Author:         Kevin
 * @CreateDate:     2019/5/9 23:58
 * @UpdateUser:     Kevin
 * @UpdateDate:     2019/5/9 23:58
 * @UpdateRemark:   修改内容
 * @Version: 1.0
 */

/**
 * 每一个任务
 */
@Data
@Slf4j
public class ScheduleQuartzJob1 implements BaseJob {
    @Autowired
private TaskMapper taskMapper;
    @Autowired
    QuartzController quartzController;
    public ScheduleQuartzJob1(){

    }
    /**
     * 具体任务
     * @param jobExecutionContext
     * @throws JobExecutionException
     */
    @Override
    public void execute(JobExecutionContext jobExecutionContext) throws JobExecutionException {
//获取任务组名称
        String group = jobExecutionContext.getJobDetail().getJobDataMap().get("group").toString();
        //获取任务名
        String name = jobExecutionContext.getJobDetail().getJobDataMap().get("name").toString();
        //具体业务逻辑 ....
        log.info("任务组：" + group + "的任务：" + name + "执行了定时任务：...." + "执行时间：" + new Date());
        //必须添加下面这一句才能够调用其他类方法
        quartzController = (QuartzController) SpringContextJobUtil.getBean("quartzController");

            System.out.println(quartzController.findall());

    }
}