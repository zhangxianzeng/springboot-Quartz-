package com.kevin.demo.entity;

import org.quartz.Job;

public interface BaseJob extends Job {
}
