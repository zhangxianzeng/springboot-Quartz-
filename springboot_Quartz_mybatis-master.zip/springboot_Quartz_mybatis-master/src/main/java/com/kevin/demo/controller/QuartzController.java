package com.kevin.demo.controller;

import com.kevin.demo.entity.*;
import com.kevin.demo.mapper.TaskMapper;
import com.kevin.demo.service.QuartzService;
import com.kevin.demo.service.ShiyanService;
import com.kevin.demo.service.TaskService;
import com.kevin.demo.util.AjaxResult;
import lombok.extern.slf4j.Slf4j;
import org.quartz.SchedulerException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.List;

/**
 * @Description:    DOTO
 * @Author:         Kevin
 * @CreateDate:     2019/5/10 12:49
 * @UpdateUser:     Kevin
 * @UpdateDate:     2019/5/10 12:49
 * @UpdateRemark:   修改内容
 * @Version: 1.0
 */
@Controller
@ResponseBody
@Slf4j
@RequestMapping("/task")
public class QuartzController {
@Autowired
private TaskMapper taskMapper;
@Autowired
    ShiyanService shiyanService;
    @Autowired
    private TaskService taskService;

    /*******************************************
     缺陷：
            xxx.class:代表任务类，主要是任务需要执行的逻辑
            先写死是ScheduleQuartz.class
            新增加任务话就修改
     ***************************************/

    /**
     * 开启任务
     * @param group
     * @param name
     * @return
     * @throws Exception
     */
    @RequestMapping("/start")
    public AjaxResult start(String group, String name,String path) throws Exception {

        Class classpath = getClass(path).getClass();
        return taskService.startTask(group, name,classpath);
    }



    /**
     * 终止任务
     * TODO 每次任务能够终止下来，但是会出现相同触发器定义的错误，但是不影响程序的运行
     * @param group
     * @param name
     * @param cron
     * @return
     * @throws Exception
     * ScheduleQuartzJob.class用来表明哪一个job类进行定时任务配置
     * path值输入方式com.kevin.demo.entity.ScheduleQuartzJob包名加类名就能够具体到某一个任务类前提是任务类实现了BaseJob接口
     */
    @RequestMapping("/stop")
    public AjaxResult stop(String group, String name, String cron,String path) throws Exception {
        Class classpath = getClass(path).getClass();
        return taskService.stopTask(group, name, classpath, cron);
    }

    /**
     * 暂停任务
     * @param group
     * @param name
     * @param cron
     * @return
     * @throws Exception
     */
    @RequestMapping("/pause")
    public AjaxResult pause(String group, String name, String cron,String path) throws Exception {
        Class classpath = getClass(path).getClass();
        return taskService.pauseTask(group, name, classpath, cron);
    }

    /**
     * 恢复任务
     * @param group
     * @param name
     * @param cron
     * @return
     * @throws Exception
     */
    @RequestMapping("/resume")
    public AjaxResult resume(String group, String name, String cron,String path) throws Exception {
        Class classpath = getClass(path).getClass();
        return taskService.resumeTask(group, name, classpath, cron);
    }

    /**
     * 查询所有任务
     * @return
     */
    @RequestMapping("/selectAllTask")
    public AjaxResult selectAllTask(){
        return taskService.selectAllTask();
    }

    /**
     * 更新执行频度
     * @param group
     * @param name
     * @param cron
     * @return
     */
    @RequestMapping("/updateCron")
    public AjaxResult updateCron(String group, String name,String cron) throws SchedulerException {
        MyJob myJob = new MyJob();
        myJob.setTaskGroup(group);
        myJob.setTaskName(name);
        myJob.setCron(cron);
        return taskService.updateCron(myJob);
    }

    /**
     * 新增任务
     * @param group
     * @param name
     * @param cron
     * @return
     */
    @RequestMapping("/insertTask")
    public AjaxResult insertTask(@RequestParam("group")String group,
                                 @RequestParam("name")String name,
                                 @RequestParam("cron")String cron,
                                  String path) throws Exception{
        Class classpath = getClass(path).getClass();
        MyJob myJob = new MyJob();
        myJob.setTaskGroup(group);
        myJob.setTaskName(name);
        myJob.setCron(cron);
        //开启任务
        myJob.setStatus("1");

        return taskService.insertTask(myJob,classpath);
    }
    @RequestMapping("/shiyan")
    public List<DingShi> findall(){
        return taskMapper.findAll();
    }
    @RequestMapping("/add")
    public int add(DingShi dingShi){

        return shiyanService.add(dingShi);
    }
    //getClass方法是根据那么任务类实现BaseJob接口而得到具体到任务类到名称以及路径，最后任务类和BaseJob放在一个目录下
    public static BaseJob getClass(String classname) throws Exception
    {
        Class<?> class1 = Class.forName(classname);
        return (BaseJob)class1.newInstance();
    }

}

