package com.kevin.demo.service;

import com.kevin.demo.entity.DingShi;
import com.kevin.demo.mapper.TaskMapper;
import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ShiyanService {
    @Autowired
    private TaskMapper taskMapper;
    public int add(DingShi dingShi){

        return taskMapper.add(dingShi);
    }
}
